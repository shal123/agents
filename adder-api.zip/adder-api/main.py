import os
from flask import Flask, request, jsonify

app = Flask(__name__)

@app.route('/add', methods=['POST'])
def add_numbers():
    data = request.get_json()
    try:
        # Extract integers from request body
        num1 = int(data.get('a'))
        num2 = int(data.get('b'))
        result = num1 + num2
        return jsonify({"sum": result}), 200
    except (TypeError, ValueError):
        return jsonify({"error": "Please provide two integers 'a' and 'b'"}), 400

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=int(os.environ.get("PORT", 8080)))
